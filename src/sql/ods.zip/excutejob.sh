#!/bin/bash
#执行job
sqoop job --exec category
sqoop job --exec user_extend
sqoop job --exec user_addr
sqoop job --exec user
sqoop job --exec us_order
sqoop job --exec user_pc_click
sqoop job --exec user_app_click
sqoop job --exec order_item
sqoop job --exec order_delivery
#导入数据
hive -e "load data inpath '/qfbap/ods/ods_code_category/*' into table qfbap_ods.ods_code_category";
hive -e "load data inpath '/qfbap/ods/ods_user_extend/*' into table qfbap_ods.ods_user_extend ";
hive -e "load data inpath '/qfbap/ods/ods_user_addr/*' into table qfbap_ods.ods_user_addr";
hive -e "load data inpath '/qfbap/ods/ods_user/*' into table qfbap_ods.ods_user";
hive -e "load data inpath '/qfbap/ods/ods_us_order/*' into table qfbap_ods.ods_us_order partition(dt='2019-07-09')";
hive -e "load data inpath '/qfbap/ods/ods_user_pc_click_log/*' into table qfbap_ods.ods_user_pc_click_log partition(dt='2019-07-09')";
hive -e "load data inpath '/qfbap/ods/ods_user_app_click_log/*' into table qfbap_ods.ods_user_app_click_log partition(dt='2019-07-09')";
hive -e "load data inpath '/qfbap/ods/ods_order_item/*' into table qfbap_ods.ods_order_item partition(dt='2019-07-09')";
hive -e "load data inpath '/qfbap/ods/ods_order_delivery/*' into table qfbap_ods.ods_order_delivery partition(dt='2019-07-09')";