#!/bin/bash
sqoop job --create category -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table code_category \
--delete-target-dir \
--target-dir /qfbap/ods/ods_code_category \
--fields-terminated-by '\001' \
##
sqoop job --create user_extend -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table user_extend \
--delete-target-dir \
--target-dir /qfbap/ods/ods_user_extend \
--fields-terminated-by '\001' \
##
sqoop job --create user_addr -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table user_addr \
--delete-target-dir \
--target-dir /qfbap/ods/ods_user_addr \
--fields-terminated-by '\001' \
##
sqoop job --create user -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table user \
--delete-target-dir \
--target-dir /qfbap/ods/ods_user \
--fields-terminated-by '\001' \
##
sqoop job --create us_order -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table us_order \
--target-dir /qfbap/ods/ods_us_order \
--incremental append \
--check-column order_id \
--last-value 0 \
--fields-terminated-by '\001' \
##
sqoop job --create user_pc_click -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table user_pc_click_log \
--target-dir /qfbap/ods/ods_user_pc_click_log \
--incremental append \
--check-column log_id \
--last-value 0 \
--fields-terminated-by '\001' \
##
sqoop job --create user_app_click -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table user_app_click_log \
--target-dir /qfbap/ods/ods_user_app_click_log \
--incremental append \
--check-column log_id \
--last-value 0 \
--fields-terminated-by '\001' \
##
sqoop job --create order_item -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table order_item \
--target-dir /qfbap/ods/ods_order_item \
--incremental append \
--check-column user_id \
--last-value 0 \
--fields-terminated-by '\001' \
##
sqoop job --create order_delivery -- import \
--connect jdbc:mysql://Jshu1:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table order_delivery \
--target-dir /qfbap/ods/ods_order_delivery \
--incremental append \
--check-column order_id \
--last-value 0 \
--fields-terminated-by '\001' 