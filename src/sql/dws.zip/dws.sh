#!/bin/bash
hive -f /home/hive_dws_create_table.sql;
hive -f /home/dws.sql;