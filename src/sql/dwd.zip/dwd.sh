#!/bin/bash
hive -f /home/hive_dwd_create_table.sql;
hive -f /home/dwd.sql;